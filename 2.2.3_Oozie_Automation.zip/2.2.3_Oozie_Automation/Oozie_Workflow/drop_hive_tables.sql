USE CDW_SAPP;

DROP TABLE if exists CDW_SAPP_F_CREDIT_CARD_Oozie;

DROP TABLE if exists CDW_SAPP_D_CUSTOMER_Oozie;

DROP TABLE if exists CDW_SAPP_D_BRANCH_oozie;

DROP TABLE if exists CDW_SAPP_TIMEID_Oozie;

DROP TABLE if exists Partition_CREDITCARD_Oozie;

DROP TABLE if exists Partition_CUSTOMER_Oozie;

DROP TABLE if exists Partition_BRANCH_Oozie;

DROP TABLE if exists Partition_TIMEID_Oozie;
