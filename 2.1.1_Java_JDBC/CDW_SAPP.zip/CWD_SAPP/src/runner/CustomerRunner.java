package runner;
import java.util.ArrayList;
import java.util.Scanner;

import dao.CustomerDao;
import model.Customer;
import model.Transaction;


public class CustomerRunner {
static Scanner scan = new Scanner(System.in);
	
	// Customer Details Module 4
	public void customerBySSN() {
		try {
			System.out.print("Enter Customer SSN: ");
			int ssn = scan.nextInt();
			System.out.println();
			
			
			CustomerDao cDAO = new CustomerDao();
			Customer cust = cDAO.getCustomerBySSN(ssn);
			System.out.println("First Name: " + cust.getfName());
			System.out.println("Middle Name: " + cust.getmName());
			System.out.println("Last Name: " + cust.getlName());
			System.out.println("SSN: " + cust.getSsn());
			System.out.println("Credit NO: " + cust.getCreditNo());
			System.out.println("APT NO: " + cust.getAptNo());
			System.out.println("Street: " + cust.getStreet());
			System.out.println("City: " + cust.getStreet());
			System.out.println("State: " + cust.getState());
			System.out.println("Country: " + cust.getCountry());
			System.out.println("Zip: " +  cust.getZip());
			System.out.println("Phone: " + cust.getPhone());
			System.out.println("Email: " + cust.getEmail());
		} catch (java.util.InputMismatchException e) {
			System.out.println("SSN NOT AN INTEGER.");
		} catch (java.lang.NullPointerException e) {
			System.out.println("SSN DOES NOT EXIST.");
		}
	}
	
	
	
	//  Customer Details Module 5
	public void modifyCustomer() {
		try {
			System.out.print("Enter Customer SSN: ");
			int ssn = scan.nextInt();
			scan.nextLine(); //CONSUME END OF INPUT
			System.out.println();
			
		
			//Print out customer current info
			System.out.println("CURRENT INFO");
			CustomerDao cDAO = new CustomerDao();
			Customer cust = cDAO.getCustomerBySSN(ssn);
			System.out.println("First Name: " + cust.getfName());
			System.out.println("Middle Name: " + cust.getmName());
			System.out.println("Last Name: " + cust.getlName());
			System.out.println("SSN: " + cust.getSsn());
			System.out.println("Credit NO: " + cust.getCreditNo());
			System.out.println("APT NO: " + cust.getAptNo());
			System.out.println("Street: " + cust.getStreet());
			System.out.println("City: " + cust.getCity());
			System.out.println("State: " + cust.getState());
			System.out.println("Country: " + cust.getCountry());
			System.out.println("Zip: " +  cust.getZip());
			System.out.println("Phone: " + cust.getPhone());
			System.out.println("Email: " + cust.getEmail());
			System.out.println();
			
			//User input changes for customer; 0 to skip
			System.out.println("CHANGES FOR " + cust.getlName() + ", " + cust.getfName() + ". ENTER '0' TO SKIP:");
			System.out.print("Change for First Name: "); String fName = scan.nextLine(); if (fName.equals("0")) fName = cust.getfName();
			System.out.print("Change for Middle Name: "); String mName = scan.nextLine(); if (mName.equals("0")) mName = cust.getmName();
			System.out.print("Change for Last Name: "); String lName = scan.nextLine(); if (lName.equals("0")) lName = cust.getlName();
			System.out.print("Change for Apt NO: "); String apt = scan.nextLine(); if (apt.equals("0")) apt = cust.getAptNo();
			System.out.print("Change for Street: "); String street = scan.nextLine(); if (street.equals("0")) street = cust.getStreet();
			System.out.print("Change for City: "); String city = scan.nextLine(); if (city.equals("0")) city = cust.getCity(); 
			System.out.print("Change for State (ST): "); String st = scan.next().toUpperCase(); if (st.equals("0")) st = cust.getState(); 
			scan.nextLine(); //CONSUME END OF INPUT
			System.out.print("Change for Zip: "); String zip = scan.next(); if (zip.equals("0")) zip = cust.getZip(); 
			scan.nextLine(); //CONSUME END OF INPUT
			System.out.print("Change for Country: "); String country = scan.nextLine(); if (country.equals("0")) country = cust.getCountry();
			System.out.print("Change for Phone: "); int phone = scan.nextInt(); if (phone == 0) phone = cust.getPhone();
			System.out.print("Change for Email: "); String email = scan.next(); if (email.equals("0")) email = cust.getEmail();
			
			//Cancel changes and terminate
			System.out.println();
			System.out.print("Would you like to commit the above changes? (y/n): ");
			if (scan.next().toLowerCase().equals("n")) {
				System.out.println("CHANGES CANCELED!");
			} else {
				//Modify customer info in database
				CustomerDao mCDAO = new CustomerDao();
				Customer mCust = mCDAO.modifyCustomer(fName, mName, lName, apt, street, city, st, country, zip, phone, email, ssn);
				
				//Print out modified customer
				cust = cDAO.getCustomerBySSN(ssn);
				System.out.println();
				System.out.println("MODIFIED INFO:");
				System.out.println("First Name: " + cust.getfName());
				System.out.println("Middle Name: " + cust.getmName());
				System.out.println("Last Name: " + cust.getlName());
				System.out.println("SSN: " + cust.getSsn());
				System.out.println("Credit NO: " + cust.getCreditNo());
				System.out.println("APT NO: " + cust.getAptNo());
				System.out.println("Street: " + cust.getStreet());
				System.out.println("City: " + cust.getCity());
				System.out.println("State: " + cust.getState());
				System.out.println("Country: " + cust.getCountry());
				System.out.println("Zip: " +  cust.getZip());
				System.out.println("Phone: " + cust.getPhone());
				System.out.println("Email: " + cust.getEmail());
			}
		} catch (java.util.InputMismatchException e) { //input mismatch type
			System.out.println("YOUR INPUT IS NOT VALID, NO CHANGES MADE. TRY AGAIN......");
		} catch (java.lang.NullPointerException e) {
			System.out.println("SSN DOES NOT EXIST.");
		}
	}
	
	
	
	//  Customer Details Module 6
	public void billByDate() {
		try {
			System.out.print("Enter Card NO: ");
			String card = scan.next();
			System.out.print("Enter a Month: ");
			int month = scan.nextInt();
			System.out.print("Enter a Year: ");
			int year = scan.nextInt();
			System.out.println();
			
			//TEST DATA 	Card: 4210653349028689 Month: 1 Year: 2018
			CustomerDao cDAO = new CustomerDao();
			Customer cust = cDAO.getCreditBillByMonthYear(card, month, year);
			System.out.println("Bill: " + cust.getSum());
		} catch (java.util.InputMismatchException e){
			System.out.println("DATE NOT AN INTEGER.");
		} catch (java.lang.Exception e) {
			System.out.println("NO DATA.");
		}
	}
	
	
	
	//  Customer Details Module 7
	public void sumByDate() {
		try {
			System.out.print("Enter Customer SSN: ");
			int ssn = scan.nextInt();
			System.out.print("Enter 1st Date (MM/DD/YYYY): ");
			String date1 = scan.next();
			System.out.print("Enter 2nd Date (MM/DD/YYYY): ");
			String date2 = scan.next();
			System.out.println();
			
			
			//TEST DATA 	SSN: 123454839 Date1: 3/1/2017 Date2: 8/31/2018
			CustomerDao cDAO = new CustomerDao();
			ArrayList<Transaction> tran = cDAO.getTranByCustDate(ssn, date1, date2);
			System.out.printf(" %-8s %-7s %-7s %-9s %-23s %-14s %-13s %-7s \n", "#ID", "#Day", "#Month","#Year","#Credit_card NO","#Branch Code" , "#Transaction Type","#Transaction Value");
			for (Transaction n: tran) {
			System.out.printf(" %-8s %-7s %-7s %-9s %-32s %-12s %-18s %-7s \n", n.getTranID(), n.getDay(), n.getMonth(),n.getYear(),n.getCreditNo(),n.getBranchCode() , n.getTranType(),n.getTranVal());	
			}
		} catch (java.util.InputMismatchException e) {
			System.out.println("SSN NOT AN INTEGER.");
		}
	}


}
