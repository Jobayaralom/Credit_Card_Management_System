package runner;

import java.util.ArrayList;
import java.util.Scanner;

import dao.TransactionDao;
import model.Transaction;


public class TransactionRunner {static Scanner scan = new Scanner(System.in);

//Transaction Details Module 1
public void tranByZip() {
	try {
		System.out.print("Enter a Zipcode: ");
		String zip = scan.next();
		System.out.print("Enter a Month: ");
		int month = scan.nextInt();
		System.out.print("Enter a Year: ");
		int year = scan.nextInt();
		System.out.println();
		
		TransactionDao tDAO = new TransactionDao();
		ArrayList<Transaction> tran = tDAO.getTranByZip(zip, month, year);
		System.out.printf(" %-8s %-7s %-7s %-9s %-17s %-12s %-10s %-9s %-7s \n", "#ID", "#Day", "#Month","#Year","#Credit_card NO","#SSN","#Branch Code" , "#Transaction Type","#Transaction Value");
		for (Transaction n : tran) {
			System.out.printf(" %-8s %-7s %-7s %-9s %-17s %-12s %-12s %-18s %-7s \n", n.getTranID(), n.getDay(), n.getMonth(),n.getYear(),
					n.getCreditNo(),n.getSsn(),n.getBranchCode() , n.getTranType(),n.getTranVal());
		}
	} catch (java.util.InputMismatchException e) {
		System.out.println("DATE NOT AN INTEGER.");
	}
}


//Transaction Details Module 2
public void tranSumByTranType() {
	try {
		System.out.print("Enter a Transaction Type: ");
		String type = scan.next();
		System.out.println();
		
		TransactionDao tDAO = new TransactionDao();
		Transaction tran = tDAO.getTranSumByTranType(type);
		System.out.println("Number of Transactions: " + tran.getCount());
		System.out.println("Total Value: " + tran.getTranVal());
	} catch (java.lang.Exception e) {
		System.out.println("NO DATA.");
	}
}



//Transaction Details Module 3
public void tranSumByState() {
	System.out.print("Enter a State Abbreviation: ");
	String state = scan.next().toUpperCase();
	System.out.println();
	
	TransactionDao tDAO = new TransactionDao();
	ArrayList<Transaction> tran = tDAO.getTranSumByState(state);
	System.out.printf(" %-15s %-22s %-7s  \n", "#BankName", "#Transactions_Number", "#Total Amount");
	for (Transaction n : tran) {
		System.out.printf(" %-24s %-15s %-7s  \n", n.getTranType(), n.getCount(), n.getTranVal());
	}
}

}
