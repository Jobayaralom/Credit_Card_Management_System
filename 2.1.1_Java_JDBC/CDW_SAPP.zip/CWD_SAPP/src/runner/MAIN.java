package runner;

import java.util.Scanner;

public class MAIN {
	
	public static void main(String[] args) {
		while (true) {
			CustomerRunner cust = new CustomerRunner();
			TransactionRunner tran = new TransactionRunner();
			
			System.out.println("                      ## CHOOSE AN ACTION YOU WANT TO PERFORM ## :");
			System.out.println(" ");
			//Transaction Details Module
			System.out.println("1. DISPLAY THE TRANSACTIONS MADE BY CUSTOMERS LIVING IN A GIVEN ZIP CODE FOR A GIVEN MONTH AND YEAR:");
			System.out.println("2. DISPLAY THE NUMBER AND TOTAL VALUES OF TRANSACTIONS FOR A GIVEN TYPE:");
			System.out.println("3. DISPLAY THE NUMBER AND TOTAL VALUES OF TRANSACTIONS FOR BRANCHES IN A GIVEN STATE:");
			//Customer Details Module
			System.out.println("4. DISPLAY THE EXISTING ACCOUNT DETAILS OF A CUSTOMER USING CUSTOMER'S SSN:");
			System.out.println("5. MODIFY THE EXISTING ACCOUNT DETAILS OF A CUSTOMER:");
			System.out.println("6. GENERATE MONTHLY BILL FOR A CREDIT CARD NUMBER FOR A GIVEN MONTH AND YEAR:");
			System.out.println("7. DISPLAY THE TRANSACTIONS MADE BY A CUSTOMER BETWEEN TWO DATES:");
			System.out.println();
			Scanner scan = new Scanner(System.in);
			System.out.print("SELECT AN ACTION 1 - 7 TO PERFORM TASK OR ENTER '0' TO QUIT: ");
			String sel = scan.next();
			
			
			switch (sel) {
			case "0":
				System.out.println("   THANK YOU SO MUCH FOR TESTING.I HOPE YOU ENJOYED ME");
				System.out.println("                  GOOD BYE PROGRAMMER ");
				scan.close();
				System.exit(0);
			case "1":
				tran.tranByZip();
				break;
			case "2":
				tran.tranSumByTranType();
				break;
			case "3":
				tran.tranSumByState();
				break;
			case "4":
				cust.customerBySSN();
				break;
			case "5":
				cust.modifyCustomer();
				break;
			case "6":
				cust.billByDate();
				break;
			case "7":
				cust.sumByDate();
				break;
			default :
				System.out.println("NOT A VALID INPUT FOR ACTION.");
			}
	
			
			System.out.println();
			System.out.println();
		}//end of while loop
	}


}


